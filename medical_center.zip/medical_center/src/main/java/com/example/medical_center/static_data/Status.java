package com.example.medical_center.static_data;

public enum Status {
    COMPLETED,
    CREATED,
    CANCELLED
}
