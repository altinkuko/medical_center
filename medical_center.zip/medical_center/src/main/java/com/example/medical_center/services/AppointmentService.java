package com.example.medical_center.services;

import com.example.medical_center.dao.Appointment;

import java.util.List;

public interface AppointmentService extends CrudService<Appointment, Long, String> {
}
