package com.example.medical_center.services;

public interface ReportService {
}
