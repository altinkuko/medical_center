package com.example.medical_center.static_data;

public enum Role {
    ROLE_ADMIN,
    ROLE_EMPLOYEE
}
