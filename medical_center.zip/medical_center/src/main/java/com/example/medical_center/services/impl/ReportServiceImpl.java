package com.example.medical_center.services.impl;

import com.example.medical_center.services.ReportService;
import org.springframework.stereotype.Service;

@Service
public class ReportServiceImpl implements ReportService {
}
