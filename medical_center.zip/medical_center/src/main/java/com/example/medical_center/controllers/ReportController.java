package com.example.medical_center.controllers;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class ReportController {
}
