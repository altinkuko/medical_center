package com.example.medical_center;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicalCenterApplicationTests {

	@Test
	void contextLoads() {
	}

}
